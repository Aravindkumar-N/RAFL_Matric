<nav class="sidebar sidebar-offcanvas" id="sidebar">
    <ul class="nav">
        <li class="nav-item {{ (request()->route()->getName() == 'dashboard') ? 'active' : '' }}">
            <a class="nav-link" href="{{url('/dashboard')}}">
                <i class="icon-grid menu-icon"></i>
                <span class="menu-title">Dashboard</span>
            </a>
        </li>
        <li class="nav-item {{ (request()->route()->getName() == 'category.index') ? 'active' : '' }}">
            <a class="nav-link"  href="{{url('/category')}}">
                <i class="icon-layout menu-icon"></i>
                <span class="menu-title">Category</span>
            </a>
        </li>
        <li class="nav-item {{ (request()->route()->getName() == 'image.index') ? 'active' : '' }}">
            <a class="nav-link"  href="{{route('image.index')}}">
                <i class="bi bi-images menu-icon"></i>
                <span class="menu-title">Gallery</span>
            </a>
        </li>
                <li class="nav-item {{ (request()->route()->getName() == 'news-event.index') ? 'active' : '' }}">
            <a class="nav-link"  href="{{route('news-event.index')}}">
                <i class="bi bi-calendar2-event menu-icon"></i>
                <span class="menu-title">News & Events</span>
            </a>
        </li>
        <!-- </li>-->
        <!--        <li class="#">-->
        <!--    <a class="nav-link"  href="#">-->
        <!--        <i class="bi bi-file-image menu-icon"></i>-->
        <!--        <span class="menu-title">Event Image</span>-->
        <!--    </a>-->
        <!--</li>-->
    </ul>
</nav>
